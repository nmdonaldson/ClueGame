package experiment;

/**
 * 
 * @author Nolan Donaldson, Chase Patterson
 *
 */

public class BadConfigFormatException {

	public BadConfigFormatException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
